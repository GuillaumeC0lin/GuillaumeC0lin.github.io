-- phpMyAdmin SQL Dump
-- version 3.3.9.2
-- http://www.phpmyadmin.net
--
-- Serveur: 127.0.0.1
-- Généré le : Mar 25 Janvier 2022 à 18:03
-- Version du serveur: 5.5.10
-- Version de PHP: 5.3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `tourisme`
--

-- --------------------------------------------------------

--
-- Structure de la table `organisme`
--

CREATE TABLE IF NOT EXISTS `organisme` (
  `rsoc` varchar(20) NOT NULL,
  `star` varchar(20) NOT NULL,
  `add` varchar(20) NOT NULL,
  `mail` varchar(20) NOT NULL,
  `tel` varchar(20) NOT NULL,
  `prix` varchar(20) NOT NULL,
  `pet` varchar(20) NOT NULL,
  `ville` varchar(20) NOT NULL,
  `type` varchar(20) NOT NULL,
  `log` varchar(20) NOT NULL,
  `pwd` varchar(20) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `organisme`
--

INSERT INTO `organisme` (`rsoc`, `star`, `add`, `mail`, `tel`, `prix`, `pet`, `ville`, `type`, `log`, `pwd`, `id`) VALUES
('non', '2', 'chez lui', '33@mail.com', '0633554422', '150', 'oui', 'nice', 'Sport', '33', '33', 1);
