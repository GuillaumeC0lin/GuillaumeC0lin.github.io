<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title></title>
		<style type="text/css">
			body
			{
				background: url(b3.png);
				background-repeat: no-repeat;
				background-size: cover; 
			}
			td
			{
				color: #2020ef;
				font-size: 20px;
				padding: 2px 2px 2px 2px;
			}
			table
			{
				margin: auto;
				border: 1px solid gold;
				border-radius: 15px;
				padding: 5px 5px 5px 5px;
				margin-top: 10%
			}
		</style>
	</head>
	<body>
		<form method="post" action="form.php">
			<table>
				<tr>
					<td>
						raison sociale :
					</td>
					<td>
						<input type="text" name="soc">
					</td>
				</tr>
				<tr>
					<td>
						Etoiles :
					</td>
					<td>
						<input type="text" name="sta">
					</td>
				</tr>
				<tr>
					<td>
						adresse :
					</td>
					<td>
						<input type="text" name="add">
					</td>
				</tr>
				<tr>
					<td>
						tel :
					</td>
					<td>
						<input type="text" name="tel">
					</td>
				</tr>
				<tr>
					<td>
						mail :
					</td>
					<td>
						<input type="text" name="mail">
					</td>
				</tr>
				<tr>
					<td>
						prix :
					</td>
					<td>
						<input type="text" name="pri">
					</td>
				</tr>
				<tr>
					<td>
						animaux autorisés:
					</td>
					<td>
					<v style="color: black;">
						<input type="radio" name="an" value="oui">oui<input type="radio" name="an" value = non>non
						</v>
					</td>
				</tr>
				<tr>
					<td>
						ville :
					</td>
					<td>				
					<input list="vil" name="vil">
						<datalist id="vil">
							<option value="paris" name="paris"></option>
							<option value="nice" name="nice"></option>
							<option value="marseille" name="marseille"></option>
							<option value="ajax" name="ajaccio"></option>
							<option value="toulon" name="toulon"></option>
						</datalist>
					</td>
				</tr>
				<tr>
					<td>
						type :
					</td>
					<td>
					<input list="type" name="typ">
						<datalist id="type">
							<option value="Thalasso" name="Thalasso"></option>
							<option value="Hotel" name="Hotel"></option>
							<option value="Sport" name="Sport"></option>
							<option value="Monument" name="Monument"></option>
							<option value="Agence de Voyage" name="Agence de Voyage"></option>
							<option value="Agence de location de voiture" name="Agence de location de voiture"></option>
							<option value="Restaurant" name="Restaurant"></option>
							<option value="Association" name="Association"></option>
							<option value="Presse" name="Presse"></option>
						</datalist>
					</td>
				</tr>
				<tr>
					<td>
						login :
					</td>
					<td>
						<input type="text" name="log">
					</td>
				</tr>
				<tr>
					<td>
						mot de passe :
					</td>
					<td>
						<input type="password" name="pas">
					</td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" name=""></td>
				</tr>
			</table>
		</form>
	</body>
</html>