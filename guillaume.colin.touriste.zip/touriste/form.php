	<meta charset="utf-8">
	<?php
		mysql_connect("localhost","root","");
		mysql_select_db("tourisme");
		
		$a = $_POST['soc'];
		$b = $_POST['sta'];
		$c = $_POST['add'];
		$c1 = $_POST['mail'];
		$d = $_POST['tel'];
		$e = $_POST['pri'];
		$f = $_POST['an'];
		$g = $_POST['vil'];
		$h = $_POST['typ'];
		$i = $_POST['log'];
		$j = $_POST['pas'];

		
		$req1 = "INSERT INTO organisme VALUES('$a','$b','$c','$c1','$d','$e','$f','$g','$h','$i','$j','')";
		$ret = mysql_query($req1);

		if (!$ret) {
    			$message  = 'Requête invalide : ' . mysql_error() . "\n";
    			$message .= 'Requête complète : ' . $req1;
    			die($message);
			}
		
		echo "<p align='center'><b><font size='7' color='#ff3399' face='Kunstler Script'> L'enregistrement a été effectué </font></b></p>";
		mysql_close();
	?>